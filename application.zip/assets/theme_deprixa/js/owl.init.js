//Owl Carousel
$("#customer-testi").owlCarousel({
  autoPlay: 3000,
  items: 3,
  itemsDesktop : [1024,3],
  itemsDesktopSmall : [900,2],
  itemsTablet: [600,1],
});