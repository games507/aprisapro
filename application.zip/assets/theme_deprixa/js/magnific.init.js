//Cta Video
$('.video-play-icon').magnificPopup({
    disableOn: 375,
    type: 'iframe',
    mainClass: 'mfp-fade',
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false,
});