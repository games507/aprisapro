
<div class="theme-main-menu theme-menu-one menu-white main-p-color">
	<div class="d-flex align-items-center">
		<div class="logo mr-auto"><a href="index.php"><?php echo ($core->logo) ? '<img src="'.SITEURL.'/uploads/'.$core->logo.'" alt="'.$core->site_name.'" class="logo" width="190" height="39"/>': $core->site_name;?></a></div>
		<div class="right-content">
			<ul class="d-flex align-items-center">
				<li><button class="sidebar-menu-open"><img src="<?php SITEURL ?>assets/images/icon/menu-black.svg" alt=""></button></li>
			</ul>
		</div>
		
	</div>
</div> <!-- /.theme-main-menu -->