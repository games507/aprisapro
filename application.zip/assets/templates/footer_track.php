		
		<!-- jQuery first, then Popper.js, then Bootstrap JS -->
    	<!-- jQuery -->
		<script src="<?php SITEURL ?>assets/vendor/jquery.2.2.3.min.js"></script>
		<!-- Popper js -->
		<script src="<?php SITEURL ?>assets/vendor/popper.js/popper.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="<?php SITEURL ?>assets/vendor/bootstrap/js/bootstrap.min.js"></script>
	    <!-- menu  -->
		<script src="<?php SITEURL ?>assets/vendor/mega-menu/assets/js/custom.js"></script>
		<!-- AOS js -->
		<script src="<?php SITEURL ?>assets/vendor/aos-next/dist/aos.js"></script>
		<!-- WOW js -->
		<script src="<?php SITEURL ?>assets/vendor/WOW-master/dist/wow.min.js"></script>
		<!-- js ui -->
		<script src="<?php SITEURL ?>assets/vendor/jquery-ui/jquery-ui.min.js"></script>
		<!-- Select js -->
		<script src="<?php SITEURL ?>assets/vendor/selectize.js/selectize.min.js"></script>
		<!-- owl.carousel -->
		<script src="<?php SITEURL ?>assets/vendor/owl-carousel/owl.carousel.min.js"></script>
		
		
		<!-- javascript -->
        <script src="<?php SITEURL ?>assets/theme_deprixa/js/bootstrap.bundle.min.js"></script>
        <script src="<?php SITEURL ?>assets/theme_deprixa/js/jquery.easing.min.js"></script>
        <script src="<?php SITEURL ?>assets/theme_deprixa/js/scrollspy.min.js"></script>
        <!-- SLIDER -->
        <script src="<?php SITEURL ?>assets/theme_deprixa/js/owl.carousel.min.js"></script>
        <script src="<?php SITEURL ?>assets/theme_deprixa/js/owl.init.js"></script>
        <!-- Main Js -->
        <script src="<?php SITEURL ?>assets/theme_deprixa/js/app.js"></script>


		<!-- Theme js -->
		<script src="<?php SITEURL ?>assets/js/theme.js"></script>
		</div> <!-- /.main-page-wrapper -->
	</body>
</html>