<link href="../assets/css_log/front.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="../assets/jquery-ui.css" type="text/css" />
<script type="text/javascript" src="../assets/js/jquery.js"></script>
<script type="text/javascript" src="../assets/js/jquery-ui.js"></script>
<script src="../assets/js/jquery.ui.touch-punch.js"></script>
<script src="../assets/js/jquery.wysiwyg.js"></script>
<script src="../assets/js/global.js"></script>
<script src="../assets/js/custom.js"></script>
<script src="../assets/js/modernizr.mq.js" type="text/javascript" ></script>
<script src="../assets/js/checkbox.js"></script>
<link href="dist/css/style.min.css" rel="stylesheet">

<script>
$(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});
</script>

<div class="row justify-content-center">
	<div class="col-md-6">
		<div class="row">
			<!-- Column -->
			<div class="col-12">
				<div id="msgholder"></div>
			</div>
		</div>
	</div>
</div>