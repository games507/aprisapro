
<div class="inner-content"><a href="install.php">pre-installation check</a> &raquo; configuration &raquo; completed</div>
<h2 id="install">License Agreement</h2>
<iframe src="license.php" class="license" frameborder="0" scrolling="auto"></iframe>
<div class="">
  <button type="button" class="btn btn-danger" onclick="document.location.href='install.php?step=2';" name="next" tabindex="3">Next</button>
</div>
